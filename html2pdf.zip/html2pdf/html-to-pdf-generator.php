<?php
/**
 * Plugin Name: HTML to PDF Converter
 * Description: Converts HTML/web pages to PDF while preserving layout, styling, and content.
 * Version: 1.0
 * Author: Your Name
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

// Define the plugin directory
define('HTML_TO_PDF_PLUGIN_DIR', plugin_dir_path(__FILE__));

// Include DOMPDF library
require_once HTML_TO_PDF_PLUGIN_DIR . 'lib/dompdf/autoload.inc.php';
use Dompdf\Dompdf;
use Dompdf\Options;

/**
 * Enqueue scripts and styles for both admin and frontend.
 */
function html_to_pdf_enqueue_scripts() {
    wp_enqueue_script('jquery');
    wp_enqueue_script('html-to-pdf-scripts', plugin_dir_url(__FILE__) . 'assets/js/html-to-pdf.js', ['jquery'], '1.0', true);
    wp_enqueue_style('html-to-pdf-styles', plugin_dir_url(__FILE__) . 'assets/css/html-to-pdf.css', [], '1.0');
}
add_action('wp_enqueue_scripts', 'html_to_pdf_enqueue_scripts');
add_action('admin_enqueue_scripts', 'html_to_pdf_enqueue_scripts');

/**
 * Handle the PDF generation process using DOMPDF
 */
function html_to_pdf_generate_pdf() {
    $url = esc_url_raw($_POST['pdf_url']);
    if (!$url) {
        wp_die(__('Invalid URL', 'html-to-pdf'));
    }

    // Fetch the HTML content
    $response = wp_remote_get($url);
    if (is_wp_error($response) || wp_remote_retrieve_response_code($response) !== 200) {
        wp_die(__('Failed to fetch the page content.', 'html-to-pdf'));
    }

    $html = wp_remote_retrieve_body($response);

    // Set up DOMPDF options
    $options = new Options();
    $options->set('isHtml5ParserEnabled', true);
    $options->set('isRemoteEnabled', true);

    $dompdf = new Dompdf($options);
    $dompdf->loadHtml($html);

    // Set paper size and orientation
    $paper_size = isset($_POST['pdf_paper_size']) ? sanitize_text_field($_POST['pdf_paper_size']) : 'A4';
    $orientation = isset($_POST['pdf_orientation']) ? sanitize_text_field($_POST['pdf_orientation']) : 'portrait';
    $dompdf->setPaper($paper_size, $orientation);

    // Render the PDF
    $dompdf->render();

    // Output the generated PDF
    $dompdf->stream('converted.pdf', ['Attachment' => true]);
    exit;
}
add_action('admin_post_html_to_pdf_generate', 'html_to_pdf_generate_pdf');

/**
 * Add a shortcode for the frontend PDF generation button
 */
function html_to_pdf_shortcode() {
    ob_start();
    ?>
    <form method="post" action="<?php echo admin_url('admin-post.php'); ?>">
        <input type="hidden" name="action" value="html_to_pdf_generate">
        <label for="pdf_url">Enter URL:</label>
        <input type="url" id="pdf_url" name="pdf_url" required>
        <label for="pdf_paper_size">Paper Size:</label>
        <select id="pdf_paper_size" name="pdf_paper_size">
            <option value="A4">A4</option>
            <option value="Letter">Letter</option>
        </select>
        <label for="pdf_orientation">Orientation:</label>
        <select id="pdf_orientation" name="pdf_orientation">
            <option value="portrait">Portrait</option>
            <option value="landscape">Landscape</option>
        </select>
        <button type="submit">Generate PDF</button>
    </form>
    <?php
    return ob_get_clean();
}
add_shortcode('html_to_pdf', 'html_to_pdf_shortcode');

/**
 * Add an admin menu for the plugin
 */
function html_to_pdf_add_admin_menu() {
    add_menu_page(
        __('HTML to PDF', 'html-to-pdf'),
        __('HTML to PDF', 'html-to-pdf'),
        'manage_options',
        'html-to-pdf',
        'html_to_pdf_admin_page',
        'dashicons-media-document',
        20
    );
}
add_action('admin_menu', 'html_to_pdf_add_admin_menu');

/**
 * Render the admin page for the plugin
 */
function html_to_pdf_admin_page() {
    ?>
    <div class="wrap">
        <h1><?php _e('HTML to PDF Converter', 'html-to-pdf'); ?></h1>
        <form method="post" action="<?php echo admin_url('admin-post.php'); ?>">
            <input type="hidden" name="action" value="html_to_pdf_generate">
            <label for="pdf_url">Enter URL:</label>
            <input type="url" id="pdf_url" name="pdf_url" required>
            <label for="pdf_paper_size">Paper Size:</label>
            <select id="pdf_paper_size" name="pdf_paper_size">
                <option value="A4">A4</option>
                <option value="Letter">Letter</option>
            </select>
            <label for="pdf_orientation">Orientation:</label>
            <select id="pdf_orientation" name="pdf_orientation">
                <option value="portrait">Portrait</option>
                <option value="landscape">Landscape</option>
            </select>
            <button type="submit" class="button button-primary">Generate PDF</button>
        </form>
    </div>
    <?php
}